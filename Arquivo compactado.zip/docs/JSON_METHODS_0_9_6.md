# Nova 0.9.6 — JSON methods

The JSON derives now expose class-style and value-style method syntax, while
keeping the 0.9.5 APIs fully compatible.

```nova
extern fn puts(text: str) -> i32;

#[derive(Serialize, Deserialize)]
struct User { id: u64, name: str }

fn main() -> i32 {
    let user = User::fromJson("{\"id\":42,\"name\":\"Nova\"}");
    let encoded: str = user.toJson();
    puts(encoded);

    // Equivalent static form:
    let also_encoded: str = User::toJson(user);

    // Existing stdout API:
    User_write_json(user);
    // New explicit stdout method (returns i32):
    user.writeJson();
    return 0;
}
```

The `fromJson` method requires `Deserialize`. The `toJson` and `writeJson`
methods require `Serialize`. All work for both `struct` and `class`.

`toJson()` **returns JSON text**; it does not print. The serializer recursively
appends nested structs to a single buffer, correctly formatting signed and
unsigned integers, boolean values and JSON-escaped UTF-8 strings.

The returned `str` currently uses a process-lifetime allocation, matching the
existing `from_json` deserialized string storage policy. It must eventually be
replaced by ownership-aware `String`/RAII for long-lived servers and loops.

`fromJson` still aborts with a diagnostic when JSON is invalid. Recoverable
`tryFromJson() -> Result<T, JsonError>` remains for a later release.

No LALRPOP grammar change is needed: `::` function paths and instance method
calls already exist.

## Test

```sh
cargo build
cargo test
cargo run -- run examples/advanced/json_methods_096.nova
```

Expected output:

```json
{"id":200,"name":"Nova \"Language\"","address":{"zip":99000,"active":true}}
```

The executable should exit with code 0. The old
`examples/advanced/json_from_struct_095.nova` must also continue to work.
