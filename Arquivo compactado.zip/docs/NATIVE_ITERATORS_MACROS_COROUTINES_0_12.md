# Nova 0.12: sintaxe de coroutines, macros AST e for-in

## Operadores de linguagem

`gen fn`, `coro fn`, `async fn`, `yield` e `await` continuam válidos.
Agora os programas podem usar `next stream`, `finished stream`, `resume handle`,
`resume(handle, input)`, `join task`, `spawn task` e `dispose handle`.
Essas expressões são traduzidas pelo parser para chamadas de baixo nível da STD.
O backend de corrotinas ainda usa handles u64 opacos. Portanto as operações
são **syntactic sugar**, não ainda Future<T> ou Generator<T> parametrizados.
A distinção de `next` entre um valor emitido e o resultado final exige
checar `finished stream` **após** obter o valor.
Os handles continuam recursos proprietários e precisam ser liberados uma vez.

## Macros declarativas sobre nós AST

```
macro twice($value:expr) => $value + $value;
macro check($condition:expr) => { if !$condition { return 1; } }
macro bind($name:ident, $value:expr) => { let $name = $value; }
```

Parâmetros suportados: `expr`, `ident`, `path`, `literal`. Os parâmetros antigos
sem tipo (`macro twice(value) => ...;`) são compatíveis e representam `expr`.
O parser cria AST e o expansor substitui os nós AST antes da análise de tipos.
Macros que expandem em statements têm escopo léxico para suas variáveis.
Limites atuais: sem token-tree repetition (`$()*`), procedural macros, quote/unquote,
macros que definem `item` ou higiene completa de identificadores, nem parser
específico para fragmentos de tipo ou statements como argumento.

## Protocolo de iterador para structs

`for element in collection { ... }` usa os seguintes métodos, escritos em Nova:

- `collection.begin() -> Cursor`
- `collection.end() -> Cursor`
- `cursor.equals(end: Cursor) -> bool`
- `cursor.value() -> T`
- `cursor.next() -> Cursor`

`for index in start..end` permanece disponível para inteiros. O `for-in`
avança corretamente antes de `continue` e não avança após `break`.
A fonte é avaliada uma vez e o compilador cria variáveis temporárias em
escopo privado. `std::vec::Int64Vector` e `ByteVector` implementam o protocolo.
Os cursors são empréstimos não-protegidos pelo compilador: não podem sobreviver
à coleção original. Ainda não há garantia geral de ownership/borrow checking.

## Verificação

```
cargo test
cargo run -- build examples/packages/language_features_012
./examples/packages/language_features_012/target/nova-app
```

O ambiente de criação não possui Rust/Cargo, por isso esta entrega requer
compilação e validação no computador do usuário. Trate os testes adicionados
como regressões pendentes de execução, não como testes já aprovados.
