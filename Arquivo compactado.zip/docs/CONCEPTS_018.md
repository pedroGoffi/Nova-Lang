# Nova 0.18 development — compile-time concepts

The compiler implements a deliberately bounded, C++20-inspired concept system without executable compile-time code. Predicate evaluation occurs at generic specialization (surface lowering), before HIR, MIR and LLVM; concept definitions are erased.

## Syntax

```nova
concept Numeric<T> = integer<T> || floating<T>;
concept Small<T> = Numeric<T> && !same_as<T, f64>;
concept Compatible<A, B> = same_as<A, B>;

static_assert(integer<i32> && !floating<i32>);

fn add<T: Small>(a: T, b: T) -> T { return a + b; }
fn check<T, U>(a: T, b: U) -> i32 where Compatible<T,U>, numeric<T> { return 0; }
```

Supported predicates: `integer<T>`, `signed<T>`, `unsigned<T>`, `floating<T>`, `numeric<T>`, `boolean<T>`, `pointer<T>`, `reference<T>`, `same_as<T,U>`, `implements<T,Trait>`, user-defined concepts, `!`, `&&`, `||`, parentheses, boolean literals. Comma-separated `where` clauses are logical AND. `static_assert(predicate);` checks a concrete predicate during the same early validation pass.

The standard library reuses these predicates in `std::concepts`:
`Integral<T>`, `SignedIntegral<T>`, `UnsignedIntegral<T>`, `FloatingPoint<T>`, `Arithmetic<T>`, `Boolean<T>`, `Pointer<T>`, `Reference<T>`, and `SameAs<T,U>`.
These have no runtime representation.

`implements<T,Trait>` checks that the named trait has an explicit compatible `impl` for the concrete type; a parent's contract may be satisfied through a derived trait's impl. It does not infer structural satisfaction from methods alone.

The compiler validates unknown names, duplicate declarations, bad arities and concept cycles before monomorphization. Unsatisfied concept bounds produce an error with the concept name and substituted concrete types. Generic templates are instantiated only for used signatures.

### Limits

* Requires-expression blocks (e.g. `requires(T x) { x.foo(); }`), associated type concepts and negative impls are not implemented.
* There is no overload resolution based on constraints, constraint subsumption or concept partial ordering.
* `impl` generics and generic struct declarations do not yet accept `where` clauses.
* Structural equality of a fully monomorphized generic user type is not yet canonicalized against a source-level applied type in every case.
* `implements<T,Trait>` depends on the existing trait checker and explicit impl machinery, not a new proof engine. Generic impl matching is limited.
* Compilation and LALRPOP have NOT been tested in this container (Cargo/rustc missing). The unit and integration tests must run on the user's machine.

## Validate

```sh
cargo build
cargo test concepts
cargo test
cargo run -- run examples/packages/concepts_018
```
