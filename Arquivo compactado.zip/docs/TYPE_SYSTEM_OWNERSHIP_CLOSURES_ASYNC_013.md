# Nova 0.13 development — scope and limitations

## Syntax added

```nova
typedef Integer = i32;

trait Arithmetic {
    fn doubled(self: Self) -> Self;
}

trait<T in i8, i16, i32, i64> IntegerMath extends Arithmetic {
    fn add(self: T, other: T) -> T;
}

impl IntegerMath for i32 {
    fn doubled(self: i32) -> i32 { return self + self; }
    fn add(self: i32, other: i32) -> i32 { return self + other; }
}
```

The alternative spelling `trait IntegerMath<T in i8, i16, i32, i64>` is
accepted. `typedef` is a *transparent alias* and not a distinct nominal type.
The `in` clause defines a **closed set of allowed types** for implementing the
trait, **not** a runtime union type. Each concrete type currently needs its own
`impl` body. The compiler verifies required method signatures and parent
contracts, detects cycles, rejects non-eligible types, and uses the existing
static method-dispatch machinery. There are no trait objects, associated types,
`where` bounds or blanket implementations in this release.

## Closures

```nova
let offset: i32 = 2;
let compute = fn(value: i32) -> i32 { return value + offset; };
let answer: i32 = compute(40);
```

For captured variables whose types can be determined in the local AST,
closure lifting creates an ordinary Nova struct holding a **copy** of the
captured value and a `call(self, ...)` method. Closures without captures stay
ordinary typed function pointers, preserving backwards compatibility with
Express. Capture mutation is rejected; mutable closures and borrowing an
external variable are not supported. Capturing resources with `drop()` is
rejected by the existing HIR owning-field check, not moved implicitly.
When the outer local has a nontrivial inferred type, an explicit local type
annotation may still be required.

## Ownership and RAII

`std::ownership::Drop` is a checked contract with `drop(self)->()`.
The existing HIR/MIR inserts lexical destruction for types implementing
`drop`. Explicit `defer` remains available. Copying an owned struct into an
owning field is rejected. This is **not yet a borrow checker**: there is no
complete lifetime inference, alias analysis, shared/mutable safe references,
or general move-initialization flow analysis.

## Async runtime

`std::task::Scheduler` exposes `poll()` and `run()` for cooperative scheduling;
`std::task::start(handle)` returns an owned RAII `Task`; `yield_now()` is a
coroutine suspension primitive. Dropping a scheduled coroutine removes its
pending scheduler entry (cancellation) to prevent stale-handle access.
`await` still uses the existing Linux/POSIX stackful coroutine backend with
`i64` results and `u64` *internal* handles. There is no multithreaded executor,
work stealing, epoll/kqueue or general `Future<T>` protocol yet. Long-running
blocking system calls will block the cooperative executor.

## Validation

The C coroutine runtime was checked using Clang and executed with the
new `runtime/tests/task_scheduler_test.c`, including scheduler cancellation.
The Rust compiler was **not** compiled or tested in the artifact environment
because Cargo/rustc were unavailable. The Rust/LALRPOP integration and E2E
Nova executables must be compiled by the recipient. Do not treat these changes
as a verified release until `cargo test` and the two examples pass.
