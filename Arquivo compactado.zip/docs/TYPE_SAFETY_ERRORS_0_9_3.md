# Nova 0.9.3 — Segurança de tipos, contratos do MIR e erros

## Escopo IMPLEMENTADO neste incremento

1. Conversões numéricas implícitas **sem perda de informação** em posições com tipo esperado (declarações locais, argumentos, retornos e expressões tipadas). O lowering insere `Expr::Cast`, e o backend gera a instrução LLVM pertinente.
2. Cast explícito `as` continua disponível para conversões potencialmente truncantes. Nenhuma conversão implícita de inteiro com sinal para inteiro sem sinal; `i64 -> f64` tampouco é implícita porque nem todos os valores são exatos.
3. Verificação estrutural da inferência genérica: unificação de tipos nomeados, argumentos aplicados, tamanho de arrays e mutabilidade de ponteiros. A instância concreta continua monomorfizada no surface lowering.
4. Validação adicional de instruções MIR: tipo dos dois operandos binários, operador compatível com tipo, argumentos de chamadas, campos de construtores estruturais e tipos de índices.
5. STD: `Option<T>.unwrap_or(fallback)`, `Result<T,E>.unwrap_or(fallback)`, `Result<T,E>.error_or(fallback)`; novo `std::error::Error {code, message}` com `with_message`.
6. `std::panic::fail(message)` e `std::panic::check(condition,message)` com mensagem e saída de processo (status 101). `NOVA_BACKTRACE=1` fornece **somente** endereços/símbolos nativos no Linux, não stack trace de código-fonte Nova.
7. Testes de compilador para widening, rejeição de conversões potencialmente truncantes, inferência genérica e parsing da STD. Exemplo `examples/advanced/numeric_inference_093.nova`.

## Regras de widening (exemplos)

| Origem | Destino | Implícito | Motivo |
|---|---|---|---|
| `i32` | `i64` | sim | mesmo sinal, mais bits |
| `u8` | `i16` | sim | todos os valores cabem |
| `i32` | `f64` | sim | 32 bits inteiros cabem na precisão de 53 bits |
| `f32` | `f64` | sim | maior precisão |
| `i64` | `i32` | não | truncamento |
| `i32` | `u64` | não | negativos não cabem |
| `u64` | `f64` | não | não representa todos os valores exatamente |
| `f64` | `i32` | não | conversão potencialmente truncante |

## APIs básicas

```nova
let small: i32 = 17;
let big: i64 = small;       // cast implícito seguro
let narrowed: i32 = big as i32; // cast explícito
```

Erros recuperáveis devem ser modelados como `Result<T,E>` e tratados com `match` exaustivo. **Ainda não existe operador `?` implementado neste pacote.** Panic **não** faz unwinding e **não** executa `drop`/`defer` pendentes; não use panic para sinalizar falha recuperável.

## Não implementado (não confundir com promessa)

- Borrow checker, `move`, lifetimes, destruição recursiva e ownership completo.
- Resolução de overloads, traits, interfaces, tipos associados, `where`, const generics, opaque types e `never`.
- Vtables dinâmicas, referências base/derivada e destrutores virtuais.
- Operador `?`, `try` e unwinding seguro; a STD mantém `match` para tratamento de erros.
- Executor/futures tipados, threads seguras, channels e rede async de produção.
- Otimizações interprocedurais, cache incremental, builds reproduzíveis e cross-compilation testada.

O nome da versão é incremental (`0.9.3`) e não representa finalização de toda a lista do roadmap.

## Como validar na sua máquina

```bash
cargo build
cargo test
cargo run -- run examples/advanced/numeric_inference_093.nova
cargo run -- bootstrap-selfhost
```

**Estado da validação local:** sanity Python/CST e sintaxe do runtime C verificadas; o ambiente de geração não possui `cargo`/`rustc`, portanto compilação Rust/LALRPOP/LLVM não foi demonstrada.
