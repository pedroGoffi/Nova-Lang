> DOCUMENTAÇÃO HISTÓRICA — ver `docs/STDLIB_020_NEXO_ABI.md` para a arquitetura atual.

# Nova 0.15: atributos de função (`[[unsafe]]`)

Esta atualização introduz atributos declarativos em funções Nova, métodos, funções genéricas, `gen/coro/async fn` e funções externas da ABI C.

## Exemplos

```nova
[[unsafe]] extern fn native_ping() -> i32;

[[unsafe]] fn ping_native() -> i32 {
    return native_ping(); // permitido: a própria função é unsafe
}

fn main() -> i32 {
    unsafe { return ping_native(); }
}
```

Também aceita o estilo histórico `#[unsafe] fn ...`, `pub [[unsafe]] fn ...`, `[[unsafe]] pub fn ...`, `#[unsafe] pub fn ...`, e `impl S { [[unsafe]] fn method(self:S) ... }`.

## Política de segurança

- A anotação `[[unsafe]]` é armazenada no AST e validada (`unsafe` não recebe argumentos; duplicatas e nomes desconhecidos são erros).
- O atributo é propagado pelas especializações de funções genéricas e métodos para as assinaturas do HIR.
- Uma chamada direta a função `[[unsafe]]` exige bloco `unsafe { ... }` no chamador ou que a própria função chamadora seja `[[unsafe]]`.
- O corpo de uma função marcada `[[unsafe]]` é um contexto `unsafe` (inclusive para operações de ponteiros brutos).
- Declarações `extern fn` não são automaticamente unsafe. A verificação anterior por nome `std__raw__*`, `std__libc__*`, `std__io__printf_i64*` ou pela presença de `...` foi removida. **A definição da API** determina a obrigação.
- Na biblioteca padrão existente, as funções do módulo `std::libc`, os entrypoints de `std::raw` e os wrappers `std::io::printf_i64` / `dprintf_i64` estão anotados explicitamente para preservar a política anterior.
- O ABI C mantém independentemente suas validações de tipos e promoções de varargs: `unsafe` não muda a ABI.
- Por segurança, não é permitido converter uma função anotada em um ponteiro de função *safe*, pois `fn(...)` ainda não representa efeitos `unsafe` no seu tipo. Essa restrição pode ser refinada quando Nova tiver `unsafe fn(...)` como tipo.

## Compatibilidade

Projetos que declaram funções externas próprias e dependiam apenas do nome ou do ABI para exigir `unsafe` devem adicionar `[[unsafe]]` à respectiva declaração. Funções FFI seguras (por contrato de API) podem continuar com `extern fn` sem atributo.

## Validação

`src/function_attributes_tests.rs` inclui testes de parser, propagação pelos módulos e lowering até LLVM, chamadas externas marcadas/não marcadas, métodos e validação de atributos. O arquivo `packages/express/src/lib.nova` teve a consulta de path ajustada para usar diretamente o handle interno em um campo de estrutura atrás de ponteiro bruto, sem construir um empréstimo inválido de um receptor temporário.

A compilação Cargo/LALRPOP ainda precisa ser executada no ambiente do desenvolvedor; o pacote não reivindica testes Rust executados neste ambiente.
