# Nova 0.15 — cinco regressões restantes de 25/10/2026

Base: `nova_0_15_test_regressions_fixed.zip` (168 testes, 163 aprovados, cinco falhas).

## Alterações

1. `grammar.lalrpop`: `Field` e `FieldInit` aceitam `MemberIdent`, permitindo
   `next: ...` em structs e inicializadores sem adicionar `next` à regra `Ident`
   (evitando a ambiguidade de operadores unários observada anteriormente).
2. `hir.rs`: parâmetros extras da ABI variádica C aceitam referências Nova
   (`&T`, `&mut T`) como argumentos de ponteiro. A chamada C continua
   obrigatoriamente dentro de `unsafe`; o borrow checker inspeciona empréstimos.
3. `coroutines.rs`: depois de expandir `yield`, `await`, `next`, `finished`,
   `dispose`, `join`, etc., a fase de lowering registra as declarações `extern`
   dos símbolos internos C ABI **apenas quando usados e ainda não declarados**.
   Assim, programas sem importação de `std` podem compilar geradores standalone
   sem depender de uma declaração externa manual. Se std já declarar o símbolo,
   não duplica a declaração.
4. Testes novos para os três cenários acima.

## Validação indicada

```bash
cargo build
cargo test
cargo test libc_tests::embedded_nested_std_links_to_real_libc_symbols -- --nocapture
cargo test module_tests::nova_012_native_iterators_ast_macros_and_generator_keywords_reach_llvm -- --nocapture
cargo test module_tests::express_async_counter_typechecks_and_generates_llvm -- --nocapture
```

## Status

As alterações foram conferidas por diff e aplicação de patch; a execução de
`cargo build`/`cargo test` **não** foi possível no ambiente de geração por não
haver um toolchain Rust instalado. Nenhuma afirmação de 168/168 testes aprovados
é feita até confirmação em um ambiente com Cargo/Rustc e LALRPOP.
