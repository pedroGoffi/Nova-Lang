# Nova 0.9.2 — Templates, classes e herança (bootstrap experimental)

A Nova usa **a mesma representação tipada de structs** para `class` e `struct`.
`class` acrescenta semântica de lifetime/RAII existente. As duas construções
aceitam templates, `impl` e herança simples com base explícita.

```nova
class Base<T> { value: T }
impl<T> Base<T> {
    virtual fn read(self: Base<T>) -> T { return self.value; }
}
class Child<T> : Base<T> { newer: T }
impl<T> Child<T> {
    override fn read(self: Child<T>) -> T { return self.newer; }
    fn original(self: Child<T>) -> T { return super.read(); }
}
fn main() -> i32 {
    auto c = new Child<i32> { value: 10, newer: 20 };
    if c.read() != 20 { return 1; }
    if c.original() != 10 { return 2; }
    return 0;
}
```

## Como o compilador implementa

- `Struct.parent: Option<TypeRef>` introduz a herança no AST, com resolução
  pelo módulo original e especialização `Base<T>` no lowering `surface`.
- O compilador valida a hierarquia antes de instanciar tipos: ciclos,
  templates com aridade errada, tipos base ausentes ou não estruturais,
  campos herdados duplicados, `override` sem ancestral, overrides de métodos
  não virtuais e assinaturas incompatíveis.
- O layout usa **prefixo de campos da base**. Não cria uma `Base` separada
  nem transforma o objeto derivado em duas regiões proprietárias.
- Os métodos herdados recebem o tipo derivado como `self` na especialização.
- `super.metodo()` gera chamada à implementação herdada da base,
  sobre os mesmos campos do objeto derivado, sem slicing.
- `virtual` e `override` participam da checagem de interface e escolha do
  método quando o **tipo concreto** está disponível ao compilador.
- Todas essas construções são eliminadas antes do HIR/MIR; LLVM continua
  recebendo structs e chamadas diretas, permitindo inlining.

## Limites importantes (não é ainda o equivalente de C++ completo)

1. **Não há polimorfismo dinâmico de classes**. `virtual`/`override` aqui não criam vtables
   LLVM; `Base` não pode reter um objeto `Child` sem slicing, nem existe `dyn Base`.
   Despacho é estático, baseado no tipo instanciado.
2. **Herança simples**: não implementa herança múltipla, mixins, interfaces,
   RTTI, `dynamic_cast`, classes abstratas ou métodos virtuais puros.
3. **Inicialização explícita**: `new Child<T> { ... }` deve informar os campos
   herdados e os campos locais. Construtores automáticos ainda não existem.
4. **Destrutores**: `drop()` herdado é reaproveitado pelo tipo derivado quando
   não há um `drop` novo. Se o derivado declara outro `drop` sobre uma base que
   já possui `drop`, o compilador rejeita o programa até que a cadeia de
   destrutores esteja implementada com ownership formal.
5. **Templates/monomorfização**: métodos e classes ainda usam especialização
   eagerly/lazily conforme `surface`, limitados por segurança da compilação.
6. **Sem ownership completo**: `move`, empréstimos/lifetimes nomeados e detecção
   geral de aliasing ainda estão pendentes. Não confunda RAII básico com C++.

## Testes recomendados

```sh
cargo build
cargo test
cargo run -- run examples/advanced/class_inheritance.nova
cargo run -- run examples/advanced/raii_defer.nova
cargo run -- bootstrap-selfhost
```

`selfhost/src/parser.nova` foi atualizado para reconhecer `: Base<T>` e
`virtual`/`override` em métodos de impl, mas o parser nativo continua sendo
fonte semântica de referência até o self-hosting completo.

## Alternativa para escolha dinâmica de implementações

A Nova já tem `enum` com payload e `match` exaustivo. A amostra
`examples/advanced/polymorphism_tagged_enum.nova` mostra escolha em
**tempo de execução** entre `Circle` e `Rectangle` sem vtable, com
`match`. Isso não é conversão implícita `Child -> Base`.
