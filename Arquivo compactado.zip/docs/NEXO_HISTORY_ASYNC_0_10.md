> DOCUMENTAÇÃO HISTÓRICA da implementação anterior do roteador.
> Package atual: `packages/nexo`. Veja `docs/STDLIB_020_NEXO_ABI.md`.

# Nova 0.10 — function values, lambdas, `packages/express`

## Architecture

```text
examples/packages/express_async_counter/src/main.nova
  └─ dependency: packages/express/src/lib.nova
       ├─ HTTP request-line/header/body parsing written in Nova
       ├─ exact / wildcard / :param route matching written in Nova
       ├─ callback/middleware lookup and dispatch written in Nova
       ├─ HTTP status/JSON/text/HTML serialization written in Nova
       ├─ request IDs supplied by a Nova `gen fn`
       └─ std::net (generic TCP byte streams)
            └─ runtime/nova_net.c (socket/bind/listen/accept/recv/send/close)
```

There are **no `std::express`, `std::http` or HTTP-specific runtime entrypoints**. `std` remains the general-purpose modular standard library (`net`, `string`, `json`, `vec`, `io`, `task`, `coro`, etc.). All HTTP/application concepts reside under `packages/express`.

## First-class function values

New syntax:

```nova
fn doubled(x:i64)->i64 { return x * 2; }

fn apply(x:i64, op:fn(i64)->i64)->i64 { return op(x); }

fn main()->i32 {
    let named:fn(i64)->i64 = doubled;
    let lambda:fn(i64)->i64 = fn(x:i64)->i64 { return x+1; };
    if apply(21,named)!=42 {return 1;}
    if apply(41,lambda)!=42 {return 2;}
    return 0;
}
```

- `fn(T1, T2) -> R` is a structural function-pointer type, carried through AST, semantic lowering, HIR, MIR, IR verification and LLVM IR emission.
- Passing a named function (`doubled`) produces a typed reference.
- `fn(x:T)->R { ... }` is lambda syntax; the compiler lifts a **capture-free** lambda into a uniquely named native Nova function.
- Calls through a variable (`op(x)`) use LLVM indirect `call` with signature verification.
- Casting a function pointer to an integer is explicit. Forging a function pointer from an integer is **unsafe** and requires an `unsafe` block. Nova 0.11 has since replaced numeric callback casts with typed native route records; see `STDLIB_REFACTOR_0_11.md`.
- **Not implemented yet:** lexical captures (`let n=1; fn(x:i64)->i64 {return x+n;}`), lifetime-tracked closures, generic/coroutine function-pointer references, safe callback unregistration while executing, and a true `Fn/FnMut/FnOnce` closure trait model. Capturing an undeclared variable is rejected rather than silently introducing global state.

## Express API

```nova
fn handler(req:express::Request,res:express::Response)->i32 {
    return res.status(200).json("{\"ok\":true}");
}

async fn serve()->i64 {
    let app=express::create(7888);
    app.use(fn(req:express::Request,res:express::Response)->bool {
        return req.id>0;
    });
    app.get("/api/:id",handler);
    app.post("/echo",fn(req:express::Request,res:express::Response)->i32 {
        return res.text(req.body);
    });
    let count:i64=app.listen(5); // 0 = indefinitely
    app.close();
    return count;
}
```

`App` supports `get`, `post`, `put`, `patch`, `delete`, `options`, `head`, `all`, `use`, `route`, `listen`, `close`. `Response` supports `status`, `type`, `send`, `text`, `html`, `json`. `Request` exposes `method`, `path`, `query`, `body`, `headers`, `id`, and `route_pattern`, plus `param("name")`, `query_value("name")` and `header("Header-Name")` methods. Helpers `matches`, `query_value`, `param_value`, `header_value` are written in Nova. In Nova 0.11 lookup helpers return managed `std::string::String` values with automatic scope cleanup. Dynamic responses from `#[derive(Serialize)]` must release derived JSON output with `std::json::release_text` as before.

Routes are applied in registration order; wildcard `*` accepts a suffix; `:id` matches a single nonempty path segment. A middleware returning `false` triggers a 403. Unknown paths produce 404. A generator supplies monotonically increasing request IDs, including unknown routes that completed request parsing.

## Building/testing on a machine with Rust/Cargo and Clang

```bash
cargo test
cargo run -- check examples/packages/lambda_callbacks
cargo run -- run examples/packages/lambda_callbacks
cargo run -- check examples/packages/express_async_counter
cargo run -- build examples/packages/express_async_counter
python3 examples/packages/express_async_counter/tests/test_server.py \
  examples/packages/express_async_counter/target/nova-app
python3 examples/packages/express_async_counter/tests/test_concurrent.py \
  examples/packages/express_async_counter/target/nova-app

# A long-running server:
cargo run -- build examples/packages/express_async_live
examples/packages/express_async_live/target/nova-app
```

Generic C TCP round-trip test (does **not** validate Nova compilation):

```bash
clang -std=c11 -Wall -Wextra -Werror -O1 \
  runtime/nova_net.c tests/net_generic_runtime.c -o /tmp/nova-net-smoke
/tmp/nova-net-smoke
```

## Honest scope and limitations

The C socket adapter passed a native loopback round-trip test in the preparation environment. The full Nova compiler **could not be compiled or exercised here**: the supplied archive omitted the original root `Cargo.toml`/lockfile, and the preparation environment did not have `cargo` or `rustc`. A minimal root `Cargo.toml` and `build.rs` were reconstructed, but are **not verified against the original manifest**. Parser conflicts, type errors and integration issues may remain until the Rust compiler and LALRPOP can run.

The new framework is **not an Express.js-compatible or production-ready server**. Transport is loopback-only, nonblocking accepts with sequential per-connection request handling, plaintext HTTP/1.1, no TLS, keep-alive, chunked transfer coding, body streaming, multipart parser, WebSocket, HTTP/2+, or production HTTP header normalization. Request length is bounded to 32 KiB and headers to 8 KiB. The current header and query helpers are simple case-sensitive byte parsers. This is a bootstrap implementation and must not be exposed directly to an untrusted public network.
