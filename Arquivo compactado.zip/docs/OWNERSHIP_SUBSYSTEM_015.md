> DOCUMENTAÇÃO HISTÓRICA — ver `docs/STDLIB_020_NEXO_ABI.md` para a arquitetura atual.

# Nova 0.15 — ownership / moves / borrows / RAII (development)

## Architecture

- **AST and LALRPOP:** `&T`, `&mut T`, safe address-of, `*reference = value` for named references. `*mut T` and `*const T` remain raw pointers, requiring `unsafe` for address acquisition and dereference.
- **Type resolution:** `TypeRef::Reference` and interned `TypeKind::Reference` are distinct from raw pointers. Both use LLVM `ptr` representation, but do *not* implicitly coerce to each other.
- **HIR ownership analysis (`src/ownership.rs`):** checks moves, post-move reads, shared and exclusive borrows, same-call aliasing, references to expired locals, assignment to live owned values, owners captured by cleanup, and conservative path merging.
- **MIR (`src/mir.rs`):** `MoveLocal` snapshots the value and clears its source owner drop flag; generated `drop` calls are guarded by per-owner runtime boolean flags on every CFG exit.
- **RAII:** owned local variables, owned by-value parameters, and discarded owned temporaries are cleaned at scope exit where the type defines `drop(self)`. A struct with owning fields but without a user-defined `drop` receives an automatically synthesized reverse-order field destructor, including fields that are fixed-size arrays of owned values.
- **Mutable borrows:** `*reference = expression` writes through an `&mut T`. Raw pointer stores still require `unsafe`. Overwriting an owned value through a borrow is intentionally rejected until safe replacement semantics exist.

## Examples

```nova
class File { descriptor: i32 }
impl File {
    fn drop(self: File) -> () { close_descriptor(self.descriptor); return; }
}
fn close_descriptor(descriptor: i32) -> () { return; }
fn main() -> i32 {
    let first = new File { descriptor: 3 };
    let second = first;       // first is moved; no double drop
    let mut count: i32 = 10;
    let view: &mut i32 = &mut count;
    *view = 20;
    return *view - 20;       // second is dropped exactly once
}
```

### Examples deliberately rejected

```nova
let first = new File { descriptor: 3 };
let second = first;
first.drop();                // use of moved value
```

```nova
let mut value: i32 = 1;
let first: &mut i32 = &mut value;
let second: &mut i32 = &mut value;   // aliasing mutable borrows
```

```nova
fn invalid() -> &i32 {
    let local: i32 = 1;
    return &local;            // borrowed local escapes scope
}
```

## Behavior / caveats

1. **Lexical borrow regions, not full NLL:** loans persist until the borrow local leaves scope, even if no longer used. This can reject safe Rust-style last-use patterns.
2. **No user-spelled lifetime parameters:** returning a reference argument directly is permitted; returning a reference to a local is rejected. Storing references inside aggregates is rejected until explicit lifetime parameters are available.
3. **No partial moves or safe replacement of owned fields:** destructors are the exception for consuming fields during finalization.
4. **No cross-thread Send/Sync proofs:** references are not yet sendable across threads under checked rules; legacy raw pointers are unsafe.
5. **Closures and async suspension:** borrow regions across suspension points, captured owning environments and cancellation require additional lifetime and pinning work. This version must not be considered a complete Rust-equivalent borrow checker.
6. **Temporary destructor limitations:** direct owned expression statements are handled, but intermediate owning temporaries inside nested expressions and some externally generated coroutine states need further drop elaboration.
7. **Compatibility:** earlier STD/package methods sometimes receive owned `self` by value for read-only operations. Under *real* move semantics this consumes the owner; these methods must be migrated to `&Self` / `&mut Self` and calls updated. The new pass deliberately does not silently make by-value calls borrow.
8. **Unsafe:** `unsafe` permits raw pointer operations, not arbitrary violations of move/borrow bookkeeping on safe references.
9. **`Copy`/`Clone` traits:** explicit user-defined Copy/Clone implementations, `drop` flags for partial aggregate moves, region inference and type-parameter bounds remain future work.

## Verification

```bash
cargo build
cargo test
cargo run -- run examples/ownership_015/main.nova
cargo run -- check examples/packages/express_async_counter
```

Native smoke tests (C/LLVM) are independent of the Rust/LALRPOP semantic tests. See the accompanying release notes for which ones were executed.
