# Nova 0.14 — implementation status (development preview)

This snapshot is an incremental compiler/runtime change on top of Nova 0.13. It does **not** implement the entire 30+ feature request. The distinction between implemented, experimental and absent is intentional.

## Implemented in this change (pending Rust compiler verification)

1. **Named arguments** for normal Nova functions, generics and unambiguous methods. Argument names are checked and calls are lowered to ordinary positional calls before HIR and LLVM.
2. **Constant default arguments** on functions and unambiguous methods. Defaults must be trailing and closed compile-time expressions; an explicitly named argument may override a default.
3. **Trait default methods**: a trait method may supply a body, which is injected into the concrete implementation when missing. Inherited default conflicts require an explicit implementation. Existing multiple trait inheritance and the `trait<T in ...>` type-family restriction remain.
4. **Struct operator dispatch**: `+`, `-`, `*`, `/`, `%`, comparison, bitwise and shift operators on user-defined structs dispatch through typechecked methods such as `add`/`eq`/`bit_and`. `std::ops` supplies checked, same-type trait contracts. Mixed operand types and generic operator bounds are not yet supported.
5. **AtomicI64** in `std::atomic`, implemented using C11 `_Atomic(int64_t)` with relaxed/acquire/release/acq_rel/sequentially-consistent orderings, atomic load/store/swap/fetch_add/fetch_sub/fetch_and/fetch_or/fetch_xor and compare-exchange. Invalid combinations are rejected by the native backend. The C11 native semantics and six-thread stress test passed.
6. **RAII cleanup** for this atomic owner via an existing `drop(self)` convention, **subject to Nova 0.13's current ownership limitations**.

### Example

```nova
trait Scalar { fn twice(self: Self) -> Self {return self+self;} }
impl Scalar for i32 {}
fn compute(value: i32, multiplier: i32 = 2, increment: i32 = 3) -> i32 {
    return value*multiplier+increment;
}
fn main() -> i32 {
    let computed = compute(5, increment: 9);
    let atomic_counter = std::atomic::create_i64(0);
    atomic_counter.fetch_add(1, std::atomic::sequentially_consistent());
    return computed.twice()-38;
}
```

## Explicit limitations of these changes

- Runtime atomics are real C11 atomics, but Nova still has **no compiler-enforced `Send` / `Sync` checking**. A type containing an atomic field is not automatically safe for cross-thread transfer.
- Passing an owned `AtomicI64` into an arbitrary function remains subject to the incomplete Nova ownership model. Do not clone an atomic owner or free an owner twice. Ownership enforcement needs a move-and-borrow analysis.
- Named arguments on overloaded methods with multiple receiver types are rejected when they cannot be resolved unambiguously in this early AST pass.
- Reordered named arguments containing side-effecting expressions are rejected, rather than silently changing evaluation order.
- Parameter defaults are restricted to compile-time expressions; arbitrary expressions, dependencies on preceding parameters, and defaults on variadic arguments are not supported.
- The self-hosted parser has not yet been updated for the v0.14 syntax.

## Requested language features not fully implemented

| Requested functionality | Current status |
|---|---|
| Named arguments and defaults | First usable AST lowering added; limitations above |
| Trait-based Iterator / IntoIterator / AsyncIterator | v0.12 cursor-based protocol only; no trait-integrated type inference |
| `?` for Option/Result | Not implemented |
| Atomics / memory ordering | `AtomicI64` C11 native implementation; no complete atomic type family |
| Send/Sync and thread checking | Not implemented |
| Typed Generator<Yield,Return> | Not implemented; existing handles remain |
| Async/await with nonblocking I/O | Existing cooperative coroutine prototype; no production async reactor |
| Typed Future<T> | Not implemented |
| Operator overload through traits | Same-type struct operator dispatch through method/trait contracts; no mixed-type or generic trait bounds |
| Function overload resolution | Not implemented; duplicate normal functions rejected by new call binder |
| Heterogeneous variadic generics | Existing homogeneous variadic packs only |
| Partial application | Not implemented |
| Functions as values | Existing pointer function types; captureless lambdas from v0.10 |
| Full closures (move/ref/mut) | Existing immutable by-value capture only |
| Move semantics + borrow checker | Not implemented |
| Lifetimes and borrow inference | Not implemented |
| Deterministic RAII / automatic Drop | Existing lexical cleanup model, incomplete for all ownership cases |
| Copy and Clone semantics | Existing derive support is limited; no trait-enforced separation |
| Box/Rc/Arc/Weak | Not implemented |
| Interior mutability | Not implemented |
| Pinning | Not implemented |
| Escape analysis | Not implemented |
| Fully generic traits + constraints | Restricted family traits/contract checking only |
| Multiple inheritance of traits | Existing support, defaults added |
| dyn Trait and dynamic vtables | Not implemented |
| Associated types | Not implemented |
| Trait bounds on generic functions | Not implemented |
| Const generics | Not implemented |
| Union / intersection types | Not implemented |
| `impl Trait` opaque return types | Not implemented |
| Advanced type inference | Existing localized inference only |

## Verification

Verified in this environment: `clang -std=c11 -Wall -Wextra -Werror -fsyntax-only runtime/nova_atomic.c`, native sources syntax, six-thread stress test and atomic CAS/add/sub/swap tests.

**Not verified:** `cargo build`, `cargo test`, LALRPOP grammar generation, Nova LLVM examples. The container has no Rust compiler/Cargo; these must pass on the user's Rust workstation before relying on the snapshot.

Suggested validation commands:

```sh
cargo test
cargo build
cargo run -- build examples/packages/language_features_014
cargo run -- run examples/packages/language_features_014
clang -std=c11 -O2 -pthread runtime/nova_atomic.c runtime/tests/atomic_semantics.c -o /tmp/nova_atomic_test && /tmp/nova_atomic_test
```
