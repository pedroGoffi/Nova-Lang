> DOCUMENTAÇÃO HISTÓRICA da implementação anterior do roteador.
> Package atual: `packages/nexo`. Veja `docs/STDLIB_020_NEXO_ABI.md`.

# Legacy 0.9.7 Express notes

This implementation was removed during the 0.10 refactor. HTTP now lives entirely in `packages/express/src/lib.nova`; see [EXPRESS_ASYNC_0_10.md](EXPRESS_ASYNC_0_10.md).
