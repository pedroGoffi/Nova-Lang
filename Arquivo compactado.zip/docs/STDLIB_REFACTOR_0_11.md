> DOCUMENTAÇÃO HISTÓRICA — ver `docs/STDLIB_020_NEXO_ABI.md` para a arquitetura atual.

# Nova 0.11 — STDLIB, resources and typed callbacks

## Design contract

1. `std` is a general-purpose library, with files named for one responsibility. HTTP and Express live in `packages/express`, never in `std` or in native C. Removed obsolete `std/src/{express,http}.nova` and the HTTP-only C adapters; the generic TCP adapter remains.
2. The `extern fn` APIs in `std` are low-level, ABI-stable bootstrap primitives. Their `u64` numbers are **runtime-owned resource handles**, not route handlers or application callbacks. Existing stage-0 callers remain supported. FFI symbol names cannot change without updating runtime C.
3. Idiomatic new code uses typed owner structs. Each owner has a `drop(self: Owner) -> ()` method. The compiler's existing scope cleanup calls this method for local variables (unless a declaration-level `defer` overrides it). Do **not** explicitly drop a local typed owner and then let scope cleanup drop it again.
4. `std::raw::size_of::<T>()` is a compiler intrinsic, evaluated using Nova's LP64 native layout. There is **no** runtime-specific `size_of_Route` or Express allocation function. Explicit pointer-to-pointer casts are supported only in `unsafe` scopes, emitted as LLVM's opaque `ptr` without integer conversions.
5. Route and middleware callbacks are stored as native typed function-pointer fields (`fn(Request,Response)->i32`, `fn(Request,Response)->bool`) in Nova-owned linked records. They are not encoded in a `u64` or `i64` vector.
6. `App` exposes a one-shot `close()` to free its two registries. Use a declaration-level cleanup so early `return`, `break` etc. do not leak resources: `let app = express::create(7888) defer app.close();`. Do not call `close()` a second time.
7. `std::libc` remains intentionally raw: C symbols, pointer types and variadic ABIs must stay recognizable. Parameter names were expanded for readability without changing linkage.

## Type-oriented modules

| Module | New type / API | Cleanup |
| --- | --- | --- |
| `std::string` | `String`, `new_string`, `from_text`, `slice`, `byte_at`, `equals` | `String.drop()` |
| `std::builder` | `StringBuilder`, `make` | `StringBuilder.drop()` |
| `std::memory` | `ByteBuffer`, `new_buffer` | `ByteBuffer.drop()` |
| `std::arena` | `Arena`, `new` | `Arena.drop()` |
| `std::vec` | `Int64Vector`, `ByteVector` | `.drop()` |
| `std::map` | `StringInt64Map` | `.drop()` |
| `std::symbol` | `SymbolTable`, `new_table` (legacy `Table` retained) | `SymbolTable.drop()` |
| `std::net` | `TcpListener`, `TcpConnection` | `.drop()` closes fd |
| `std::generator` | `Generator`, `manage` | `.drop()` |
| `std::coro` | `Coroutine`, `manage` | `.drop()` |
| `std::task` | `Task`, `delay`, `manage` | `.drop()` |
| `std::raw` | `Allocation`, `allocate`, `size_of::<T>()` | `.drop()` |
| `std::fs` | `read_string`, `save_string` | returned `String` owns content |
| `std::env` | `read` | returned `String` owns content |
| `std::convert` | `format_i64`, `parse_or` | returned `String` owns content |
| `std::json` | `quoted`, `quoted_string`, `JsonText`, `manage_serialized` | returned `String` owns content |
| `std::io` | `print_int64_lines` | no owned resource |
| `std::time` | `now_millis` | no owned resource |

Modules such as `option`, `result`, `error`, `panic`, `math` and `libc` retain their already-descriptive typed APIs. Existing raw `u64` handle entrypoints are intentionally retained where stage-0 code still depends on their ABI.

## Example of scoped ownership

```nova
fn main() -> i32 {
    let content: std::string::String = std::string::from_text("Hello");
    let output: std::builder::StringBuilder = std::builder::make();
    output.append(content.as_str());
    output.append(" Nova!");
    return 0;  // both owners are dropped by Nova
}
```

## Build and test

```bash
cargo test
cargo build
cargo run -- build examples/packages/stdlib_owners
examples/packages/stdlib_owners/target/nova-app
cargo run -- build examples/packages/express_async_counter
python3 examples/packages/express_async_counter/tests/test_server.py \
  examples/packages/express_async_counter/target/nova-app
python3 examples/packages/express_async_counter/tests/test_concurrent.py \
  examples/packages/express_async_counter/target/nova-app
bash tests/async_native_smoke.sh
```

## Known stage-0 limitations

- Single-threaded resource handles, no borrow checker or move assignment. A copied raw owner handle can double-free; typed owners should never be copied into multiple independently dropped locals. A value returned from a function transfers ownership; no move-by-assignment yet.
- TCP is loopback-only and nonblocking; HTTP in `packages/express` processes one active connection at a time. Not a production Express.js replacement. No TLS, streaming, HTTP/2 or chunked encoding.
- `str` is a borrowed, NUL-terminated string type; binary-safe bodies and connection write-all/partial-send support need dedicated buffer/view types.
- `std::raw::size_of` targets the currently supported 64-bit Linux ABI, not arbitrary platforms.
- Closure capture is still unsupported. Function pointers and capture-free lambdas work.
