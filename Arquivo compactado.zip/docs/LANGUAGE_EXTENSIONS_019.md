# Nova 0.19 Alpha — structural concepts, associated types, const evaluation, static reflection, effects

This is an **incremental source patch over Nova 0.18**, not a claim that all of
C++23/C++26 or modern Rust have been implemented. Compiler stage 0 remains
Rust/LALRPOP/LLVM, with the existing Nova-written selfhost subset.

## Implemented in this source patch

### Structural concepts (part of requested topic 1)

```nova
struct User { id: i64, active: bool }
concept HasId<T> = requires(T value) { {value.id} -> i64; };
concept Addable<T> = requires(T a,T b) { {a + b} -> T; };
static_assert(HasId<User>);
static_assert(has_field<User,active>);
```

The `requires` subset recognizes `value.field`, zero-argument `value.method()`
and the binary operations `+`, `-`, `*`, `/` on identical primitive numeric
types, with an explicit required return type. There are no general
requires-expression blocks or overload resolution yet. `has_field<T,name>`
and `has_method<T,name>` are built-in compile-time predicates; field and method
names are identifiers, not type declarations. All checks happen before LLVM.

### Associated trait types (part of requested topic 2)

```nova
trait Source {
    type Item;
    fn get(self: Self) -> Self::Item;
}
impl Source for i64 {
    type Item = i64;
    fn get(self: i64) -> i64 {return self;}
}
```

The binding is mandatory and checked against method signatures, then erased
before HIR. Associated type declarations and bindings precede trait methods.
This alpha does **not** implement generic associated types (`type View<T>`),
lifetime parameters, projections in arbitrary expressions, or associated type
normalization through all generic trait bounds.

### `const fn` (part of requested topic 3)

```nova
const fn factorial(n:i64)->i64 {
    if n<=1 {return 1;}
    return n*factorial(n-1);
}
fn main()->i32 {return (factorial(5)-120) as i32;}
```

Constant calls are folded into AST literals before HIR. Stage 0 supports
`i32`/`i64` function parameters/results, arithmetic, boolean comparisons,
`let`, assignment, `if`, returns and const-to-const calls. It uses checked
integer arithmetic, a 64-frame recursion limit and a 100000-step budget.
Calls with nonconstant arguments remain ordinary runtime calls. This is **not**
full const generics, `const` array bounds or a universal compile-time
interpreter. Invalid effects in a const function are rejected.

### Reflection + JSON derive

```nova
#[derive(Json)]
struct User { id:i64, active:bool }
fn main()->i32 {
    let descriptor:str = reflect::<User>();
    let name:str = type_name::<User>();
    return 0;
}
```

`reflect::<T>()` produces a **compile-time generated JSON string** of the
concrete type's name and field names/types (no runtime reflection metadata).
`type_name::<T>()` produces its type name as a string literal. `derive(Json)`
reuses the existing **Serialize and Deserialize** implementations and their
existing JSON field-type restrictions; it does not add a second JSON runtime.
The existing generated `T::toJson` and `T::fromJson` APIs remain in charge of
actual serialization and parsing.

### Effect contracts (requested Effects item)

```nova
[[pure]] fn double(x:i64)->i64 {return x*2;}
[[io]] fn writeAudit(x:i64)->i64 {return x;}
[[unsafe]] extern fn native(ptr:*mut u8)->i32;
[[async]] async fn work(x:i64)->i64 {return x;}
```

`[[pure]]` validates calls to declared pure/const functions, and rejects
unsafe blocks, suspension, unknown indirect calls and unverified method calls.
`[[io]]` is **informative** for now: it is not a complete effect-inference
system and does not yet require `io` on every caller. `[[unsafe]]` retains
existing HIR checking. `[[async]]` requires the async function mode; it does
not modify the stage-0 task ABI. Multiple markers use separate attributes
(`[[pure]] [[const]]`), not the unsupported combined `[[pure, const]]` syntax.
`const fn` automatically carries the `const` effect and must call other const
functions during constant evaluation.

## Existing features reused without duplicating machinery

- Capturing closures are already lowered by `src/lambdas.rs`; this patch did
  **not** implement new mutable captures or `FnMut`/`FnOnce` trait inference.
- `std::task::Task<T>`, `Future<T>`, `Generator<T>` and `Coroutine<T>` from the
  prior version remain generic **at the language surface** but the runtime
  result ABI is still restricted to i64/u64. `async fn` does not yet produce
  a general `Task<T>` automatically.
- The nominal trait checker and `implements<T,Trait>` concept are reused;
  vtables and `dyn Trait`/opaque `impl Trait` are **not** added.

## Requested features not complete in this alpha

1. Full C++20 `requires` syntax, method argument requirements and overload ordering.
2. GATs with lifetimes, associated consts and higher-ranked bounds.
3. Const generics, const array sizes and unrestricted compile-time execution.
4. Static `impl Trait` return inference and `dyn Trait` objects/vtables.
5. Closure capture syntax and `Fn`/`FnMut`/`FnOnce` semantics.
6. Typed async trait methods, safe general `Task<T>` frames, cancellation and
   structured concurrency.
7. General compile-time reflection AST capable of synthesizing arbitrary code;
   the implemented reflection returns a metadata string only.
8. Effect polymorphism/inference, method effect resolution and enforced IO
   propagation.

## Testing

These tests were added to `src/concepts_integration_tests.rs`, `src/effects.rs`
and `src/consteval.rs`. To verify on a machine with Rust and Cargo:

```bash
cargo build
cargo test
cargo run -- run examples/packages/nova_019
```

The native C integration suite remains:

```bash
bash tests/stdlib_017_native_smoke.sh
```

**Validation in the artifact-building environment:** the native C/LLVM
stdlib smoke suite passed. Rust `cargo build` and `cargo test` could not run,
because Cargo/Rust toolchain was unavailable; this source patch is therefore
**not yet verified to compile**. Run Cargo and report diagnostics before
considering the version complete.
