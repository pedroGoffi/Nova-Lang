# Nova 0.20 + Nexo 0.3 — correção de 9 falhas em `cargo test`

Esta correção foi realizada sobre o ZIP enviado em 26/10/2026.

## Diagnóstico

O log mostra 215 testes, 206 aprovados e 9 com erro:

- **Corrotinas (3 testes):** os nomes gerados pelo parser e pelo sintetizador de `extern` não correspondiam às entradas privadas (`__*`) da STD, causando `unknown function` e `duplicate extern`.
- **Nexo (4 testes):** `connection.nova` chamava `config::default_request_timeout_millis()`, definido como privado em outro arquivo.
- **Módulos (1 teste):** exemplo importava `std::io::__println` mas chamava `println`.
- **Async (1 teste):** `join` ainda gerava `std::task::block_on`, embora a STD exportasse `std::task::__block_on`.

## Mudanças

1. `src/grammar.lalrpop`: `next`, `finished`, `resume`, `join`, `spawn` e `dispose` chamam intrínsecos privados `std::*::__*`.
2. `src/coroutines.rs`: `runtime_intrinsic` sintetiza as declarações `__*` corretas, inclusive para código sem dependência explícita de STD. Os testes com declaração explícita passaram a usar `__yield_value`, evitando duplicação de nomes.
3. `packages/nexo/src/config.nova`: timeout agora é `pub const fn`.
4. `std/src/io.nova`: wrappers seguros e públicos `print`, `println`, `print_int` e `println_int`; os símbolos `__*` continuam internos.
5. `examples/packages/modules_demo/src/main.nova`: importa o wrapper público `std::io::println`.
6. Teste de regressão para todos os oito intrínsecos usados pelo lowering.

## Compatibilidade

Não foi alterada a ABI C. As funções do runtime continuam exportadas como `__nova_std__...`; a correção ajusta nomes de chamadas/declaracões Nova para esses símbolos. Recompile o compilador após alterar `grammar.lalrpop` para regenerar o parser.

## Validação feita aqui

- `bash tests/stdlib_017_native_smoke.sh`: PASS (38 módulos da STD, C/LLVM, TCP, corrotinas, scheduler, atomics, JSON, vetores etc.).
- `nm` no objeto `runtime/nova_coroutines.c`: símbolos privados `__nova_std__...` confirmados.
- **Não foi possível executar `cargo test` neste ambiente**: Rust/Cargo não estão instalados. Os 9 testes devem ser confirmados na máquina do autor.

## Aplicação

O arquivo compactado do usuário continha os subdiretórios do projeto, mas não incluía `Cargo.toml` na raiz. Aplique o patch à raiz do repositório Nova já existente, ou copie as pastas do ZIP sobre esse repositório sem apagar o manifesto.

```sh
# na raiz da Nova
 git apply --check nova_020_nexo_coroutines_test_fix.patch
 git apply nova_020_nexo_coroutines_test_fix.patch
 cargo build
 cargo test
 cargo run -- run examples/packages/nexo_modular
```
