# Nova 0.15 — correções direcionadas à suíte de 167 testes

Relatório de regressão recebido: `cargo test` concluiu com **150 aprovados / 17 falhas**.
Estas alterações são um patch sobre `nova_0_15_compile_fixed.zip`.

## Alterações

- **Grammar:** separa identificadores ordinários de nomes contextualizados de membros, funções e segmentos após `::` (`new`, `next`, `resume`, `join`, `spawn`, `finished`, `dispose`), mantendo a interpretação dos operadores prefixados.
- **C ABI/ownership:** a verificação de chamadas diretas percorre todos os argumentos variádicos além dos parâmetros fixos, já validados no HIR. Continua rejeitando agregados na camada de type checking.
- **Spread:** adia a validação de aridade quando um argumento `...array` será expandido durante monomorfização em `surface.rs`.
- **Copy/Move:** não confunde classe armazenada inline e sem destrutor com um proprietário; o tratamento recursivo de estruturas mantém uma pilha de visita, evitando falsos positivos em campos repetidos.
- **Métodos de owner:** insere empréstimo automático *apenas* de local nomeado para parâmetros `self: &T` / `self: &mut T`; não copia silenciosamente owners. Métodos não-consumidores da STDLIB atualizados; destructors `drop(self: T)` permanecem consumidores.
- **StringBuilder:** passa a possuir diretamente o handle nativo da String, para evitar empréstimos a campos sem o suporte de place projections no HIR/MIR. Snapshot (`to_string`) clona o handle e `drop` libera a alocação uma vez.
- **Módulos incorporados:** inclui `atomic.nova` e `ops.nova` na tabela de módulos embutidos.
- **Testes:** corrige dependência `std` ausente em fixture, escopo `unsafe` para raw pointer, e a asserção MIR/RAII que pressupunha que limpeza e `return` ficassem no mesmo bloco (agora há branch por drop-flag).

## Validação realizada aqui

- ZIP criado e validado (CRC e caminhos);
- Patch textual testado com `git apply --check` na origem da 0.15;
- Inspeção estática dos pontos corrigidos.

**Não executado neste ambiente:** `cargo build`/`cargo test`, porque os executáveis Cargo e Rustc não estão disponíveis. A correção está pronta para validação, mas não se deve afirmar que a suíte está verde sem rodá-la.

## Aplicar

Na raiz da sua árvore Nova 0.15 (com os arquivos da última versão):

```bash
 git apply --check nova_015_test_regressions_fix.patch
 git apply nova_015_test_regressions_fix.patch
 cargo test -- --nocapture
```

Caso já existam alterações próprias, use o ZIP completo ou reconcilie as diferenças com Git, sem forçar o patch.

## Escopo ainda limitado

O borrow checker continua conservador, lexical e sem NLL, lifetimes explícitos ou borrowing de campos/temporários. APIs nativas que modificam por uma referência compartilhada dependem do contrato interno de mutabilidade do runtime, não de uma verificação geral de interior mutability.
