> DOCUMENTAÇÃO HISTÓRICA da implementação anterior do roteador.
> Package atual: `packages/nexo`. Veja `docs/STDLIB_020_NEXO_ABI.md`.

# Nova 0.10: fix for `app.use` parser regression

The generated LALRPOP lexer recognizes `use` as a keyword rather than as the
identifier token. As a result, the previous grammar refused the standard
Express-style method name in `app.use(...)` and in `fn use(...)`.

`src/grammar.lalrpop` now accepts `use` in `Ident` contexts, matching the
existing treatment of the `coro` contextual keyword. The top-level
`use path::name;` import statement is unchanged.

A regression test in `src/parser_regressions.rs` covers both forms in one
source file; existing tests cover parsing Express and two Express examples.

## Verify on a machine with Rust/Cargo

```sh
cargo test
cargo build
cargo run -- build examples/packages/express_async_counter
```

Rust/Cargo was unavailable in the patching environment, so these commands
must be run locally to validate the full parser, typechecker and LLVM stages.
