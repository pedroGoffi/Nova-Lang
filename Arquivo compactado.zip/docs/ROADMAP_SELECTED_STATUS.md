# Status dos itens selecionados do roadmap após a Nova 0.9.3

**Legenda:** Novo = implementado neste incremento; Parcial = já existia suporte experimental e/ou o incremento adicionou apenas uma etapa; Pendente = não entregue neste incremento.

| Área | Itens selecionados | Situação comprovável pelo código |
|---|---|---|
| Tipos/inferência | 1, 2 | **Parcial**: inferência local já existia; unificação genérica agora valida arrays e ponteiros; sem solver geral de constraints |
| Tipos/inferência | 3 | **Pendente**: ranking de overloads e múltiplas assinaturas homônimas |
| Tipos/inferência | 4, 5 | **Parcial + novo**: coerções seguras em posições com tipo esperado, reuso de casts LLVM; não é um sistema completo de coercion/overload |
| Tipos/inferência | 6, 8 | **Pendente**: associated types, traits e `where T: Trait` |
| Tipos/inferência | 9, 10, 11 | **Pendente**: const generics, type aliases/opaque types, semântica formal de never/null |
| Ownership/lifetimes | 11–20 | **Pendente**: RAII lexical preexistente, sem checker formal de ownership nem drop recursivo comprovado |
| Classes e polimorfismo | 21–30 | **Parcial preexistente**: herança de layout e override estático; vtables dinâmicas, RTTI e destrutores virtuais pendentes |
| Generics | 31, 32 | **Parcial**: monomorfização existente e maior rigor na unificação; especialização ainda limitada |
| Generics | 33–37 | **Pendente**: especialização, traits, GATs, closures e coerência |
| Tratamento de erros | 46 | **Parcial + novo**: Option/Result existentes receberam métodos auxiliares; ownership de payload ainda limitado |
| Tratamento de erros | 47, 48 | **Pendente**: propagação `?` e `try` |
| Tratamento de erros | 49 | **Novo básico**: `std::error::Error`, mas não há contratos de Error trait |
| Tratamento de erros | 50 | **Parcial**: panic com mensagem e backtrace nativo opt-in (sem source-map Nova) |
| Tratamento de erros | 51 | **Definido para panic**: exit 101, sem unwinding nem RAII em panic; erros recuperáveis com Result/match |
| Async/corrotinas/concorrência | 71, 72 | **Parcial preexistente**: bootstrap de corrotinas/async com ABI limitada; Future<T> completo pendente |
| Async/corrotinas/concorrência | 73–77 | **Pendente**: executor, cancelamento com drop, canais, Send/Sync, I/O async de produção |
| Compilador/backend | 85 | **Parcial + novo**: AST/HIR/MIR/LLVM já presentes; verificador de contratos MIR fortalecido |
| Compilador/backend | 86–89 | **Pendente ou experimental**: otimizações profundas, source diagnostics completos e compilação incremental |
| Compilador/backend | 90–92 | **Parcial**: flags de target/debug existentes, não validadas para cross-compilation ampla; reprodutibilidade pendente |

**Importante:** o projeto gerado não foi compilado com `cargo` no ambiente de criação; testes Rust/LALRPOP dependem de execução na máquina de desenvolvimento. Não interpretar "Novo" como certificação de qualidade para produção.
