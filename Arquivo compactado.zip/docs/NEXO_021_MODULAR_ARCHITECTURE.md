# Nexo 0.3 — arquitetura modular (Nova 0.20)

O framework HTTP Nexo permanece **um package independente** da STDLIB e do runtime C. O arquivo `packages/nexo/src/lib.nova` publica somente os módulos e um wrapper `create` para conveniência. A implementação está separada por responsabilidade.

| Módulo | Responsabilidade |
| --- | --- |
| `request.nova` | View emprestada (`str`) da requisição; leitura de parâmetros, query e headers |
| `response.nova` | HTTP status, MIME, escrita; `StatusInteger<T>` concept |
| `method.nova` | Enum `Method`, code (`match`) e nomes de métodos |
| `path.nova` | Correspondência de rotas e parâmetros dinâmicos |
| `query.nova` | Parsing de query string |
| `headers.nova` | Headers case-insensitive, Content-Length, rejeição de TE e duplicatas |
| `routing.nova` | Registro e despacho, callbacks tipados, posse única de nodes |
| `middleware.nova` | Execução ordenada de guards tipados |
| `config.nova` | Configuração serializável via `#[derive(Json)]` e const fn |
| `app.nova` | Registro GET/POST/...; construção, encerramento e opções |
| `server.nova` | Aceitação de conexões e IDs com generator |
| `connection.nova` | Leitura, framing e despacho de uma conexão; RAII |

## API pública

Na Nova 0.20 o parser de módulos não implementa `pub use`, logo tipos ficam em seus módulos. As assinaturas de callbacks passaram de `nexo::Request` e `nexo::Response` para `nexo::request::Request` e `nexo::response::Response`. Os métodos de `App` (`get`, `post`, `use`, `listen`, `close`) e a factory `nexo::create` foram preservados. Há também `nexo::app::create`, `nexo::app::from_config`, `App.on(Method, path, callback)`, e `App.listen_config(config)`.

Exemplo:

```nova
fn welcome(req: nexo::request::Request, res: nexo::response::Response) -> i32 {
    return res.status(200).json("{\"ok\":true}");
}

async fn run_server() -> i64 {
    let app = nexo::app::create(7888) defer app.close();
    app.get("/health", welcome);
    return app.listen(0);
}

fn main() -> i32 {
    let task: std::task::Task<i64> = std::task::manage(run_server());
    return task.wait() as i32;
}
```

## Recursos da Nova utilizados intencionalmente

- **Módulos/visibilidade/imports** para arquitetura extensível.
- **Structs, enums e `match`** para requests, responses e métodos HTTP.
- **Generics + Concepts** para códigos de status tipados.
- **`#[derive(Json)]`** para configuração serializável; sem serializador duplicado.
- **`const fn` e `[[pure]]`** para funções computáveis sem efeitos de I/O.
- **`[[unsafe]]` / blocos `unsafe`** para registros intrusivos e alocação via std::raw, confinados nos registries.
- **Ownership, referências e RAII** para a conexão TCP, String e coleções.
- **Callbacks tipados e closures** para handlers e middlewares (veja demos).
- **Generator + Task<i64> + `async fn`** para IDs de requisições e entrada assíncrona de aplicação.

`GATs`, `dyn Trait` e Task<T> com tipos arbitrários **não** são simulados no package, pois a ABI do compilador ainda não os implementa integralmente.

## Limites atuais

O Nexo implementa HTTP/1.1 **loopback**, uma conexão por iteração, `Connection: close`, corpo textual até 32 KiB, headers até 8 KiB, sem TLS, sem upload binário, sem streaming/chunked, sem parsing URL-form ou percent decode. A função `listen` não equivale a um servidor multithread; `Task<i64>` serve para integração com o runtime cooperativo atual.

Conferir futuros handlers que enviam a resposta por conta própria: eles devem retornar o status da operação, mas o framework não mantém flag para detectar respostas duplicadas.

**Migração ABI:** esta versão mantém símbolos `__` na camada C/FFI. Assinaturas de request/response mudaram por causa dos módulos. Recompile packages e exemplos.

## Testes

```sh
cargo build
cargo test
cargo run -- run examples/packages/nexo_modular
cargo run -- build examples/packages/nexo_async_counter
python3 examples/packages/nexo_async_counter/tests/test_server.py examples/packages/nexo_async_counter/target/nova-app
```

Sem Cargo no ambiente de autoria, apenas testes nativos C/LLVM e checagens estruturais podem ser executados; não considerar o compilador/Rust homologado sem executar esses comandos.
