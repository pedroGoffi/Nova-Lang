# Nova 0.20 Alpha — STDLIB, Nexo e ABI nativa

## Delimitação de responsabilidades

- `std`: uso geral (strings, bytes, vetores, mapas, arquivos, rede TCP, task,
  corrotinas, atomics, traits/concepts e memória). Nada de HTTP ou routing.
- `packages/nexo`: roteador HTTP escrito inteiramente em Nova, reutilizando
  `std::net::TcpListener`, `TcpConnection`, `std::string` e funções de callback.
  Não há cópia do código-fonte do Express.js, e não há um segundo servidor
  HTTP em C embutido no runtime.
- `runtime/*.c`: **somente** primitivas de C ABI que o compilador não consegue
  implementar em Nova durante o estágio inicial do bootstrap.

## Nomes públicos versus nomes do runtime

| Camada | Exemplo | Observações |
|---|---|---|
| API Nova | `bytes.push(42)` | API tipada do usuário |
| API Nova | `bytes.at(0)` | Indexação com checagem de limites |
| API Nova | `bytes.pop()` | Retira último elemento; erro em vetor vazio |
| FFI Nova interna | `std::vec::__byte_vector_get` | Convenção `__`, não usar em aplicações |
| Símbolo ELF | `__nova_std__vec____byte_vector_get` | ABI interna, versão não estável |
| JSON runtime | `__nova_json_parse` | ABI interna |
| Coroutine runtime | `__nova_coro_create` | ABI interna |

O linker apenas remapeia **funções externas** `std__*` para `__nova_std__*`.
As funções definidas em Nova mantêm o mangling convencional. A ligação com
`std::libc::<header>::function` permanece direcionada ao símbolo da libc,
não ao runtime da Nova.

As assinaturas FFI da biblioteca padrão foram renomeadas com `__`. Isso **não**
implica segurança automática: chamadas diretas a FFI com handles ou ponteiros
podem violar ownership. Prefira os wrappers tipados; o isolamento completo de
ABI ainda depende do controle de visibilidade interna pelo compilador.

## Package Nexo

```toml
[dependencies]
std = { builtin = "std" }
nexo = { path = "../../../packages/nexo" }
```

```nova
fn hello(req: nexo::request::Request, res: nexo::response::Response) -> i32 {
    return res.text("Nova");
}
async fn serve() -> i64 {
    let app = nexo::create(7878);
    app.get("/", hello);
    return app.listen(1);
}
```

`Task<T>` e `Future<T>` continuam limitadas à representação de resultados
`i64`/`u64` do estágio 0. O runtime de corrotinas com valores arbitrários ainda
não existe. Não tratar essa limitação como concluída na versão 0.20.

## Breaking changes

1. Importar `nexo`, nunca `express` ou `std::express`.
2. `std::http` foi removido: usar Nexo para HTTP.
3. Os símbolos do runtime mudaram. **Recompilar compilador, pacotes e binários**
   gerados com as versões anteriores da Nova. Binários pré-compilados que
   dependam do ABI antigo não são compatíveis.
4. APIs de baixo nível foram renomeadas: `std::vec::__byte_vector_get` substitui
   o antigo `std::vec::u8_get`, mas código de aplicação deve usar `ByteVector.at()`.
5. O antigo `std::symbol::Table` duplicado foi retirado: usar `SymbolTable`.

## Validação

```bash
bash tests/stdlib_017_native_smoke.sh
cargo build
cargo test
cargo run -- run examples/packages/modern_std
cargo run -- build examples/packages/nexo_async_counter
python3 examples/packages/nexo_async_counter/tests/test_concurrent.py \
  examples/packages/nexo_async_counter/target/nova-app
```

A suíte C e LLVM verifica os símbolos compilados e as operações básicas;
**não substitui** `cargo test` e os testes completos do parser, ownership,
MIR/LLVM e de integração Nexo realizados com o compilador Nova.
