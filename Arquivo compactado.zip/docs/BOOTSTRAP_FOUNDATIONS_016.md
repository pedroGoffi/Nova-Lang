# Nova 0.16 alpha — bootstrap foundation / generic async owners

This increment starts the first four architectural areas of the bootstrap roadmap:
(1) syntax/types, (2) ownership/moves/borrows/RAII, (3) functions/async, and
(4) compiler HIR/MIR/LLVM. It does **not** complete every item in those four
areas, nor does it make Nova self-hosted.

## Implemented here

- `std::task::Task<T>` and `std::task::Future<T>` carry their result types in
  their static type. A zero-sized `[T;0]` marker preserves the single-u64 ABI
  layout without storing any uninitialized T.
- `std::generator::Generator<T>` and `std::coro::Coroutine<T>` also carry typed
  results. They are noncopyable owned resources because each has a `drop` method;
  ordinary lookup methods now borrow `&self` and never consume the owner.
- Typed helper functions `std::task::manage`, `future`, `delay`, `start`,
  `std::generator::manage`, `std::coro::manage` preserve i64 as the default
  return type. `manage_typed::<T>` and `future_typed::<T>` are explicitly
  `[[unsafe]]`, since callers assert a native handle's return ABI.
- Generic methods `wait`, `await_result`, `next`, `resume`, and `finished`
  return T (or bool). `await_result` uses the cooperative runtime primitive;
  it is not the blocking scheduler's `block_on` when called from a coroutine.
- `await task` and `join task` dispatch to typed methods during surface lowering;
  `next generator`, `finished generator`, `resume coroutine`, and `spawn task`
  preserve their existing syntax and use the typed wrappers when possible.
  Legacy bare-u64 coroutine programs still use the original ABI calls.
- Monomorphization checks the result-type ABI for all four typed wrapper types.
  Stage-0 is **i64/u64 only**. Instantiating `Task<MyStruct>`, `Task<f64>`,
  `Task<bool>`, etc. is a compile-time error instead of misinterpreting a value
  through an i64-returning C ABI. The type check is centralized in `surface.rs`.
- STD HTTP exposes `serve_async_future(...) -> Future<i64>`; STD Express
  exposes `App.next() -> Future<i64>` instead of an unowned u64 handle. These
  modules are now present in both the standard library module tree and the
  built-in compiler module table. Their underlying native extern declarations
  remain u64 by design. The legacy synchronous HTTP `serve_once` is only a
  declaration in this runtime and should not be used until a native
  implementation is provided.
- STD TCP and Express resource owners have borrowed, non-consuming inspection
  methods. `App` now provides deterministic `drop()` and consuming `close()`.
- Existing package examples were changed to `Task<i64>` and `Generator<i64>`.
  A typed end-to-end example is `examples/packages/typed_async_016`.
- Rust tests were added for parsing, monomorphization, rejection of aggregate
  async results, unsafe handle imports, ownership HIR, MIR verification and LLVM.

## ABI / safety limitations (must not be presented as completed)

1. `async fn` still creates a raw `u64` coroutine factory handle in compiler
   lowering. Public STD wrappers make the result type visible, but there is
   not yet a generic compiler-produced native future frame layout.
2. Stage-0 only supports i64/u64 result words. It cannot carry owning strings,
   arbitrary structs, floats, enum payloads or lifetimes across async returns.
3. Borrow checker has lexical loans; no non-lexical lifetimes, precise partial
   moves, higher-ranked lifetime bounds or safe self-referential futures.
4. Executor is single-threaded cooperative POSIX/ucontext; no Send/Sync,
   thread safety, cancellation scopes or general-purpose async I/O readiness.
5. Generator `next()` must be guarded by `finished()` and is not yet an
   `Option<T>` return. Coroutine<T> has one return/yield type, not independent
   `<Yield, Return>` associated types.
6. `Future<T>` and `Task<T>` wrap an existing handle; arbitrary `u64` handles
   from FFI cannot be proven fresh or uniquely owned by this stage-0 compiler.
7. Full trait solver, const generics, associated types, optimizer/debug info,
   incremental compilation and compiler self-hosting are separate milestones.

## Validation

Native runtime tests executed on the packaging host:

```
clang -std=c11 -O2 runtime/nova_coroutines.c runtime/tests/task_scheduler_test.c -o /tmp/scheduler && /tmp/scheduler
clang -std=c11 -O2 -pthread runtime/nova_atomic.c runtime/tests/atomic_semantics.c -o /tmp/atomics && /tmp/atomics
```

Both passed. The host has **no Rust/Cargo toolchain**, so Cargo build/test,
LALRPOP parser generation and the new Nova examples have NOT been executed.

On the developer machine (repository root):

```
cargo build
cargo test
cargo run -- run examples/packages/typed_async_016
cargo run -- bootstrap-selfhost
```

The final command runs the existing stage-1 lexer/parser bootstrap, **not**
a successful stage1/stage2 self-compilation of the compiler.
