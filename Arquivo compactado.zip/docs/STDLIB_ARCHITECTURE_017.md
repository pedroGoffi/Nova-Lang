> DOCUMENTAÇÃO HISTÓRICA — ver `docs/STDLIB_020_NEXO_ABI.md` para a arquitetura atual.

# Nova 0.17 alpha — Standard library refactoring

Status: **C runtime integrations tested**, **Rust/LALRPOP compilation NOT verified in the packaging environment**. Do not interpret the native runtime results as successful end-to-end Nova typechecking.

## Design invariants

1. Each managed native handle has a single `Drop` owner. Typed high-level functions return owned structs and accept references for read-only operations.
2. `std::libc` contains `[[unsafe]]` declarations for direct C ABI functions. The FFI implementation of safe wrappers remains inside `unsafe {}`.
3. Adoption of existing OS descriptors and record allocation/free require `[[unsafe]]`. `TcpListener::accept()` supplies a unique owner, avoiding raw descriptor adoption in the Express package.
4. `JsonText::as_str(&JsonText)` must not consume its owner; `JsonText::drop` releases only buffers registered by the JSON runtime.
5. `StringBuilder` uses the same managed String runtime as `std::string`, rather than a second owner representation. `SymbolTable` delegates its owned map storage and RAII Drop to `std::map::StringInt64Map`.
6. Async task/future/generator/coroutine wrappers preserve the generic result type at the language boundary, **but are still restricted to one-word `i64`/`u64` payloads by the compiler**.
7. Native async HTTP response bodies are copied into the coroutine argument allocation. The server does not retain a caller-owned `str` after returning a future.
8. All standard runtime entrypoints referenced from `.nova` modules must be present in the C sources linked by the driver.

## Changes by subsystem

| Module | Refactor / contract |
|---|---|
| `string` | `copy_of` and module-level `slice` borrow the source, preserving ownership; typed `String` still owns its handle |
| `builder` | `append_string` now borrows its argument; typed builder reuses String allocation while legacy raw builder remains for stage-0 |
| `memory` | `ByteBuffer::copy_from` borrows source and retains both owners |
| `fs` | `save_string` accepts `&String`, never implicitly destroys the caller's string |
| `json` | `quoted_string` borrows; `JsonText::as_str` borrows; raw `release_text` is declared `[[unsafe]]` |
| `error` | New `OwnedError` stores a managed String, complementing the existing borrowed `Error` |
| `map`/`symbol` | Preferred `SymbolTable` owns the map as a field with synthesized recursive RAII Drop; legacy Table stays for compatibility |
| `raw` | Generic record allocation and free require `unsafe` at the call site |
| `arena` | `Arena::clear()` is unsafe because outstanding child handles become invalid |
| `net` | New `TcpListener::accept()` returns the connection owner; raw fd adoption requires unsafe; descriptor close is hidden inside unsafe Drop |
| `time` | New monotonic clock for deadlines; Express timeouts no longer depend on wall clock |
| `http` | `serve_once` implemented via the same native nonblocking HTTP engine as `serve_async`; failures to create futures are caught early |
| `express` | Typed app checks failed listener/future creation; runtime linked by compiler; Nova package remains the preferred full router |
| `atomic` | Every raw pointer-based C primitive is `[[unsafe]]`, but typed `AtomicI64` exposes checked operations |
| `task`, `generator`, `coro` | Typed task ownership and its stage-0 payload limitation documented; no false promise of general layout support |
| `option`, `result`, `ops`, `vec`, `io`, `convert`, `env`, `math`, `panic`, `ownership`, `libc` | Retained and checked for runtime linkage/exports; public compatibility preserved |

## Important known limits (not safe to claim complete)

- **No full type-generic async ABI yet.** `async fn -> T` still lowers to an opaque integer handle rather than automatically producing `Task<T>` for arbitrary `T`. The wrappers support only `i64` and `u64` result layouts. This requires compiler/runtime changes, not merely STDLIB edits.
- **No complete NLL/lifetime analysis.** A borrowed `str` from a managed string can still escape its owner. Mutable interior operations on shared handles (`&String`, `&ByteBuffer`) are not yet protected by all the exclusivity rules required for Rust-like soundness.
- **Unwinding across suspended coroutine frames is not complete.** Dropping a suspended coroutine can free the native stack without invoking each Nova-level local destructor on it. Avoid tasks owning cleanup-critical resources across suspension until the async MIR is strengthened.
- **Legacy raw-handle APIs** (`std::task::manage`, `std::generator::manage`, `std::symbol::Table`, etc.) remain for stage-0 compiler compatibility. Passing aliased handles can result in runtime abort on double-free, not compile-time rejection.
- **`std::fs::read_text` aborts** on missing/invalid files; it does not yet return `Result` or `Option`. The JSON decoder also retains some decoded text until process exit because `str` lacks owning lifetime information.
- **Networking is loopback-only**, HTTP is a small plaintext server (no TLS/production parser), and the stackful coroutine runtime uses POSIX `ucontext` on Linux.

## Native verification

From the project root:

```sh
python3 tests/clean_stdlib_static.py
bash tests/runtime_smoke.sh
bash tests/async_native_smoke.sh
bash tests/map_runtime_smoke.sh
bash tests/stdlib_017_native_smoke.sh
```

On your workstation with Rust/Cargo:

```sh
cargo build
cargo test
cargo run -- check examples/packages/stdlib_contracts_017
cargo run -- run examples/packages/stdlib_contracts_017
cargo run -- check examples/packages/express_async_counter
cargo run -- run examples/packages/typed_async_016
```

Use `cargo test module_tests::stdlib_017 -- --nocapture` for the new compiler-integration regressions. Passing native C tests alone does not certify the compiler or guarantee memory safety.

## Next compiler work for production-ready STDLIB

1. Enforce `&mut` for all managed mutable collection/string methods and support sound reborrowing/field lifetimes.
2. Make `async fn (...) -> T` lower to an owned `Task<T>` automatically, with arbitrary result layout and safe task state transfer.
3. Add cancellation + frame-drop glue for suspended coroutines and pinning/lifetime restrictions.
4. Replace raw FFI adoptions with compiler-recognized unique-handle constructors, and migrate legacy bootstrap users.
5. Introduce non-aborting, typed `Result` filesystem/network errors, then run all integration examples and sanitizers in CI.
