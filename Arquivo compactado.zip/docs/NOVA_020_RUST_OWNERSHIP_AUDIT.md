# Nova 0.20 — Auditoria do borrow checker e destructor do Nexo

## Origem do problema

A implementacao do metodo `nexo::app::App::close(self: App)` chamava
`self.routes.drop()` e `self.middlewares.drop()` manualmente. O compilador
Nova 0.20 proibe consumir campos proprietarios isoladamente fora de um
`__drop` porque ainda nao possui drop flags por campo. Essa protecao e
intencional: relaxa-la poderia resultar em destruicao duplicada.

A estrutura App ja possui um `App__drop` sintetizado pelo compilador:
`RouteCollection` e `MiddlewareCollection` implementam `drop`, e
`hir.rs` sintetiza destruidores para os structs que os contem. A chamada
consumidora `app.close()` pode simplesmente retornar. O cleanup do
parametro proprietario `self` aciona o `App__drop`, que destroi os membros
em ordem inversa. Nenhum movimento parcial precisa ser permitido.

## Erro de comparacao

O diagnostico `struct/array equality requires an explicit comparison
implementation` vinha de `hir.rs` e nao mostrava a funcao nem a
expressao que causava a falha. Esse patch melhora o diagnostico para
incluir a funcao, o operador, o tipo e os operandos originais (AST).
A restricao nao foi eliminada: comparar structs/arrays ou `str` por
representacao de memoria continua incorreto sem contrato explicito.

Se aparecer um erro desse tipo apos a alteracao, copie a nova mensagem:
ela identifica a expressao exata que deve ser corrigida, seja em um
modulo Nova, seja na geracao de HIR.

## Verificacao

Executado neste ambiente: `bash tests/stdlib_017_native_smoke.sh`.
Resultado: PASS (runtime nativo, corrotinas, TCP, atomics, JSON e vetores).

NAO executado neste ambiente: `cargo build`, `cargo test`. A aprovacao
da compilacao e de todos os testes Rust precisa ser verificada no host.

Comandos no repositorio original:

```bash
cargo build
cargo test consuming_wrapper_uses_generated_nested_drop_without_partial_moves -- --nocapture
cargo test nexo -- --nocapture
cargo test
```
