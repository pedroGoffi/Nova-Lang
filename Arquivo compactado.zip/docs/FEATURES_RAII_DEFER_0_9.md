# Nova 0.9 — vida útil por escopo, `class`, `defer` e STD tipada

## API e semântica

```nova
class Connection { id: i32 }
impl Connection {
    fn close(self: Connection) -> () { close_id(self.id); return; }
    fn drop(self: Connection) -> () { self.close(); return; }
}
fn example() -> i32 {
    auto connection = connect();                     // drop automático no fim do escopo
    auto temporary = connect() defer temporary.close(); // cleanup explícito substitui drop
    defer write_log("fim da operação");             // defer convencional
    return 0;
}
```

- `class` define uma estrutura nominal com campos e métodos `impl`, inicialmente sem herança, virtual dispatch ou encapsulamento automático. A construção usa `new C { ... }`.
- `struct` também recebe destruição automática por escopo se tiver `impl T { fn drop(self: T) -> () { ... } }`.
- O compilador insere as chamadas de `drop` ao sair de blocos, incluindo `return`, `break` e `continue`. As limpezas são executadas na ordem inversa do registro (LIFO).
- `defer expr;` registra uma **expressão que deve retornar `()`**; seus argumentos são avaliados no momento da execução do cleanup. Em casos como `defer close(fd)`, o valor atual de `fd` será lido na saída do escopo.
- `auto nome = inicialização defer expressão;` registra o cleanup imediatamente após inicializar e vincular `nome`. A limpeza explícita substitui o `drop` automático dessa variável; não são invocados os dois.
- Em `return valor;`, a expressão de retorno é avaliada e copiada para um slot temporário antes das limpezas. Um retorno direto de variável proprietária transfere seu valor e suprime a destruição automática daquela variável.
- `auto` deduz o tipo da expressão de inicialização. Não modifica as regras de coerção numérica introduzidas na versão anterior.

## STD sem `u64` no StringBuilder

```nova
fn main() -> i32 {
    auto out = std::builder::make_with_capacity(128 as u64);
    out.append("Nova ");
    out.append_i64(9);
    auto text = out.to_string(); // cria uma cópia gerenciada independente
    text.println();
    return 0;  // text.drop(); out.drop();
}
```

A nova `struct StringBuilder { text: std::string::String }` armazena um valor `String` tipado em vez de um identificador numérico do builder. Seus métodos `append`, `append_i64`, `append_bool`, `append_string`, `clear`, `len`, `to_string` e `drop` são escritos em Nova. A `struct String` fornece `push`, `reserve`, `clear`, `append_i64`, `clone`, `as_str`, `println` e `drop`. O runtime C ainda representa o armazenamento interno de `String` por um identificador geracional `u64`, mas esse detalhe não aparece nos tipos ou na API do builder. As funções legadas de builder continuam presentes para compatibilidade com o bootstrap.

### Limitações de ownership nesta etapa

- **Não há um borrow checker completo**, nem lifetimes nomeados (`'a`) ou transferência de ownership geral (`move`). Cópias diretas de valores locais proprietários e de campos proprietários para inicializadores são rejeitadas quando verificáveis, para prevenir `double-free`; atribuição de variável proprietária também é rejeitada.
- Passagem por valor para métodos usa a representação existente e não transfere ownership. Ponteiros emprestados, temporários e acesso a campos ainda precisam de regras mais fortes para segurança geral.
- O runtime não autodestrói recursivamente campos proprietários: uma estrutura que contém recursos deve implementar seu próprio `drop()` e destruir seus campos uma única vez, em ordem apropriada.
- Não chame `drop()` manualmente sobre um valor que ainda terá `drop` automático. Use a forma com `defer` na declaração para substituir o destrutor por outra operação finalizadora.
- Valores proprietários construídos e descartados como expressões temporárias (sem atribuição), exceções, closures/async suspensos e saltos incomuns ainda não têm semântica de ownership completa.
- A validade da gramática e das alterações Rust precisa ser confirmada executando `cargo build` e `cargo test` em ambiente com toolchain Rust/LALRPOP. A checagem estática Python e o runtime C não substituem a compilação.

## Testes locais

```bash
cargo build
cargo test
cargo run -- check examples/advanced/raii_defer.nova
cargo run -- run examples/advanced/raii_defer.nova
cargo run -- check examples/advanced/typed_string_builder.nova
cargo run -- run examples/advanced/typed_string_builder.nova
cargo run -- bootstrap-selfhost
python3 selfhost/tests/source_sanity.py
```

Para testar arquivos que usam `std::...`, garanta que o compilador carregue a STD embutida, como nos exemplos de pacotes existentes.
