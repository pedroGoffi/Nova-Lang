# Nova 0.20 — Nomes nativos vs. código Nova e correção do Nexo

## Contrato de nomes

- **Somente a implementação C do runtime exporta nomes iniciados por `__`**, por exemplo `__nova_std__vec____byte_vector_get`.
- Em arquivos `.nova`, a camada de FFI declara `extern fn native_byte_vector_get(...)`. É uma função interna (não `pub`), mas o nome não contém `__`.
- O compilador traduz **somente externs de `std`** para o símbolo C real: `std::vec::native_byte_vector_get` → `__nova_std__vec____byte_vector_get`. Externs libc continuam usando os símbolos originais (a exceção `errno_location` é traduzida para a API C `__errno_location`); funções Nova normais mantêm o mangling padrão.
- APIs públicas continuam idiomáticas: `vector.at(0)`, `vector.push(42)`, `String.as_str()`, `println(...)`. Evite chamadas `native_*` em aplicativos.
- Nomes internos de código gerado pelo compilador (`__nova_make_...`, `__nova_body_...`) permanecem internos ao compilador. O prefixo não é um requisito para funções escritas em Nova.

## Correção Nexo: implicit borrow

O compilador 0.20 só cria um empréstimo implícito de um *local com nome*. A expressão `self.routes.add(...)` toma como receptor um campo (uma projeção), e portanto falha. Para evitar cópias de proprietários e possíveis double-free, `app.nova` passa o ponteiro da lista diretamente para funções `[[unsafe]]` de registro. Métodos do contêiner continuam delegando à mesma implementação, sem duplicar lógica. O registro conserva a responsabilidade de destruição em `App.close()`.

## Validação sugerida

```bash
cargo build
cargo test
cargo run -- run examples/packages/nexo_modular
cargo run -- build examples/packages/nexo_async_counter
```

Mudança de frontend/FFI sem alterar símbolos C nativos. Recompile pacotes Nova que referenciem diretamente os nomes antigos `std::x::__func`.
